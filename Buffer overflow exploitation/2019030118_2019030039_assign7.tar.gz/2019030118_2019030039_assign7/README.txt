Authors:
Athanasakis Evangelos 
Fragkogiannis George
 
->  To begin with, we need to get the address of the Name buffer. Since the Name buffer is a global variable (it's address doesn't change)
    we can parse the shell code there and by overwriting the eip register (return address) to point to its address we can execute our shell 
    code. That was done using the gdb debugger, by running the gdb Greeter command, in order to open the debugger. By using the command 
    "p &Name" we get the memory address of the register.

->  Payload explanation: We found out that in order to overwrite the eip register we need to overflow the buf buffer by 52bytes. The information 
    written on the eip buffer will exist in the range of 48-52 bytes, where we will parse the memory location of the Name buffer (in order to jump 
    there with the next instruction). 
    We place the shell code at the first 0-21 bytes (thats the length of the shellcode). The buf buffer is copied to the Name buffer and thus upon 
    jumping to the Name buffer address, the shell code executes.
    For the remaining free bytes (22-47) we place the no op operand "/x90" 

    The total payload will be:
                            shellcode + no_op padding + Name_buf_addr
    Which will be 52 bytes in total and will be created using the Shell_Generator.py script, that creates the binary payload.
    At first, we execute the command: "python3 Shell_Generator.py > attack.txt" in order to write the payload on the "attack.txt" file
    Then, we use the "attack.txt" as input to the ./Greeter using the command: "(cat attack.txt ; cat) | ./Greeter". Using this command
    the exploit first runs and executes a shell and then the cat takes over and we can relay input via the cat to the shell
     
-> Since we are using an intel processor, we use little endian Architecture. Thus the memory address is written in reverse using the python 
   struct.pack method.
